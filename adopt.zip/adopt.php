<?php 
    include 'connection.php';

    session_start();

    // Check if all required session variables are set
    if(!isset($_SESSION['userId']))
    {
        header('location:login.php');
        exit(); // Ensure to exit after redirection
    }

    // Initialize variables to store user's first name and last name
    $firstName = '';
    $lastName = '';

    // Retrieve user's first name and last name from the database
    $userId = $_SESSION['userId'];
    $query = "SELECT firstName, lastName FROM users WHERE userId = ?";
    $stmt = mysqli_prepare($conn, $query);
    // mysqli_stmt_bind_param($stmt, "i", $userId);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $userId);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_bind_result($stmt, $firstName, $lastName);
            mysqli_stmt_fetch($stmt);
        } else {
            // Handle SQL execution error
            echo "Error executing SQL statement: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt); // Close statement
    } else {
        // Handle SQL preparation error
        echo "Error preparing SQL statement: " . mysqli_error($conn);
    }

    $speciesFilter = isset($_GET['species']) ? $_GET['species'] : '';
    $statusFilter = isset($_GET['status']) ? $_GET['status'] : '';

    // Fetch data from the database
    $sql = "SELECT * FROM animal WHERE 1";

    // Add WHERE condition for species if filter is provided
    if (!empty($speciesFilter)) {
        $sql .= " AND species = '$speciesFilter'";
    }

    if (!empty($statusFilter)) {
        $sql .= " AND status = '$statusFilter'";
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adopt</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            /* margin: 20px; */
        }

        .card1 {
            width: 400px !important;
            margin: 20px auto;
            height: 60vh !important;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px #ccc;
            border-radius: 8px;
            overflow: hidden;
        }

        .card-img {
            width: 100%;
            height: 40vh !important;
            object-fit: cover;
        }

        .card-body {
            padding: 15px;
            text-align: center;
            background-color: #f8f8f8;
        }

        h3 {
            margin: 0;
            color: #333;
            font-size: 20px;
        }

        p {
            margin: 5px 0;
            color: #666;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            height: 100%;
            width: 100%;
            font-family: Poppins, sans-serif;
        }

        /*Background color*/
        #grad1 {
            /* background-color: : #9C27B0;
            background-image: linear-gradient(120deg, #FF4081, #81D4FA); */
        }
        
    
        #msform {
            width: 100% !important; 
            margin-right: 20px; 
        }

        #msform .form-card {
            /* Adjust form card styles */
            padding: 20px;
        }

        #msform .form-card {
    /* Adjust form card styles */
    padding: 20px;
}

#msform input,
#msform textarea,
#msform select {
    /* Expand form inputs to full width */
    width: calc(100% - 16px); /* Adjusted for padding */
}

#msform fieldset {
    /* Ensure fieldsets take full width */
    width: 100%;
}

@media (max-width: 768px) {
    /* Adjustments for smaller screens */
    .container {
        flex-direction: column; /* Stack elements vertically on small screens */
        align-items: center;
    }

    .card1,
    #msform {
        width: 100%; /* Full width on smaller screens */
        margin-right: 0;
        margin-bottom: 20px; /* Add spacing between stacked elements */
    }
}


        /*form styles*/
        #msform {
            text-align: center;
            position: relative;
            margin-top: 20px;
            width: 100%;
        }

        #msform fieldset .form-card {
            background: white;
            border: 0 none;
            border-radius: 0px;
            box-shadow: 0 2px 2px 2px rgba(0, 0, 0, 0.2);
            padding: 20px 40px 30px 40px;
            box-sizing: border-box;
            width: 94%;
            margin: 0 3% 20px 3%;

            /*stacking fieldsets above each other*/
            position: relative;
        }

        #msform fieldset {
            background: white;
            border: 0 none;
            border-radius: 0.5rem;
            box-sizing: border-box;
            width: 100%;
            margin: 0;
            padding-bottom: 20px;

            /*stacking fieldsets above each other*/
            position: relative;
        }

        /*Hide all except first fieldset*/
        #msform fieldset:not(:first-of-type) {
            display: none;
        }

        #msform fieldset .form-card {
            text-align: left;
            color: #9E9E9E;
        }

        #msform input, #msform textarea {
            padding: 0px 8px 4px 8px;
            border: none;
            border-bottom: 1px solid #ccc;
            border-radius: 0px;
            margin-bottom: 25px;
            margin-top: 2px;
            width: 100%;
            box-sizing: border-box;
            font-family: montserrat;
            color: #2C3E50;
            font-size: 16px;
            letter-spacing: 1px;
        }

        #msform input:focus, #msform textarea:focus {
            -moz-box-shadow: none !important;
            -webkit-box-shadow: none !important;
            box-shadow: none !important;
            border: none;
            font-weight: bold;
            border-bottom: 2px solid skyblue;
            outline-width: 0;
        }

        /*Blue Buttons*/
        #msform .action-button {
            width: 100px;
            background: skyblue;
            font-weight: bold;
            color: white;
            border: 0 none;
            border-radius: 0px;
            cursor: pointer;
            padding: 10px 5px;
            margin: 10px 5px;
        }

        #msform .action-button:hover, #msform .action-button:focus {
            box-shadow: 0 0 0 2px white, 0 0 0 3px skyblue;
        }

        /*Previous Buttons*/
        #msform .action-button-previous {
            width: 100px;
            background: #616161;
            font-weight: bold;
            color: white;
            border: 0 none;
            border-radius: 0px;
            cursor: pointer;
            padding: 10px 5px;
            margin: 10px 5px;
        }

        #msform .action-button-previous:hover, #msform .action-button-previous:focus {
            box-shadow: 0 0 0 2px white, 0 0 0 3px #616161;
        }

        /*Dropdown List Exp Date*/
        select.list-dt {
            border: none;
            outline: 0;
            border-bottom: 1px solid #ccc;
            padding: 2px 5px 3px 5px;
            margin: 2px;
        }

        select.list-dt:focus {
            border-bottom: 2px solid skyblue;
        }

        /*The background card*/
        .card {
            z-index: 0;
            border: none;
            width: 800px;
            border-radius: 0.5rem;
            position: relative;
        }

        /*FieldSet headings*/
        .fs-title {
            font-size: 25px;
            color: #2C3E50;
            margin-bottom: 10px;
            font-weight: bold;
            text-align: left;
        }

        /*progressbar*/
        #progressbar {
            margin-bottom: 30px;
            overflow: hidden;
            color: lightgrey;
        }

        #progressbar .active {
            color: #000000;
        }

        #progressbar li {
            list-style-type: none;
            font-size: 12px;
            width: 25%;
            float: left;
            position: relative;
        }

        /*Icons in the ProgressBar*/
        #progressbar #account:before {
            font-family: FontAwesome;
            content: "\f023";
        }

        #progressbar #personal:before {
            font-family: FontAwesome;
            content: "\f007";
        }

        #progressbar #payment:before {
            font-family: FontAwesome;
            content: "\f09d";
        }

        #progressbar #confirm:before {
            font-family: FontAwesome;
            content: "\f00c";
        }

        /*ProgressBar before any progress*/
        #progressbar li:before {
            width: 50px;
            height: 50px;
            line-height: 45px;
            display: block;
            font-size: 18px;
            color: #ffffff;
            background: lightgray;
            border-radius: 50%;
            margin: 0 auto 10px auto;
            padding: 2px;
        }

        /*ProgressBar connectors*/
        #progressbar li:after {
            content: '';
            width: 100%;
            height: 2px;
            background: lightgray;
            position: absolute;
            left: 0;
            top: 25px;
            z-index: -1;
        }

        /*Color number of the step and the connector before it*/
        #progressbar li.active:before, #progressbar li.active:after {
            background: skyblue;
        }

        /*Imaged Radio Buttons*/
        .radio-group {
            position: relative;
            margin-bottom: 25px;
        }

        .radio {
            display:inline-block;
            width: 204;
            height: 104;
            border-radius: 0;
            background: lightblue;
            box-shadow: 0 2px 2px 2px rgba(0, 0, 0, 0.2);
            box-sizing: border-box;
            cursor:pointer;
            margin: 8px 2px; 
        }

        .radio:hover {
            box-shadow: 2px 2px 2px 2px rgba(0, 0, 0, 0.3);
        }

        .radio.selected {
            box-shadow: 1px 1px 2px 2px rgba(0, 0, 0, 0.1);
        }

        /*Fit image in bootstrap div*/
        .fit-image{
            width: 100%;
            object-fit: cover;
        }

        .checkbox-label {
            display: flex; /* Use flexbox to align items */
            align-items: center; /* Center items vertically */
        }

        .checkbox-label input[type="checkbox"] {
            margin-right: 10px; /* Add spacing between checkbox and text */
        }

        .required {
            color: red;
            margin-left: 2px;
        }

        .loading-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.8);
  z-index: 9999;
  display: none;
}

.loading-paw {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100px;
  height: 100px;
  margin-top: -50px;
  margin-left: -50px;
  border: 5px solid transparent;
  border-radius: 50%;
  border-top-color: #333; /* Change color as needed */
  animation: spin 1s infinite linear;
}

@keyframes spin {
  0% {
    transform: rotate(0deg) scale(1);
  }
  25% {
    transform: rotate(45deg) scale(1.2);
  }
  50% {
    transform: rotate(90deg) scale(1);
  }
  75% {
    transform: rotate(135deg) scale(1.2);
  }
  100% {
    transform: rotate(180deg) scale(1);
  }
}


     



    </style>
</head>
<body id="page-top">

    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fa fa-paw"></i>
                </div>
                <div class="sidebar-brand-text mx-3" style="color: yellow; text-transform: none;">FurEver Finder</div>

                <!-- <div class="sidebar-brand-text mx-3">Finder</div> -->
            </a>

             <!-- Divider -->
             <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="dashboardV2.php">
                    <i class="fa fa-home"></i>
                    <span>Homepage</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link" href="animalProfileV2.php">
                    <i class="fas fa-paw"></i>
                    <span>Animal Profile</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="adoptionHistory.php">
                    <i class="fas fa-calendar"></i>
                    <span>Adoption History</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="appointment.php">
                    <i class="fas fa-calendar"></i>
                    <span>Appointment Schedule</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Send Your Donations</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa fa-shopping-cart"></i>
                    <span>Shop Now</span></a>
            </li>


            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <!-- <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form> -->

                     <!-- Topbar Navbar -->
                     <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter"></span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Notifications
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <!-- <div class="icon-circle bg-primary"> -->
                                            <!-- <i class="fas fa-file-alt text-white"></i> -->
                                        <!-- </div> -->
                                    </div>
                                    <div>
                                        <!-- <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span> -->
                                    </div>
                                </a>
                                
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Notifications</a>
                            </div>
                        </li>

                        <!-- Nav Item - Shopping Cart -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-shopping-cart"></i>
                                <!-- Counter - Shopping Cart  -->
                                <span class="badge badge-danger badge-counter"></span>
                            </a>
                            <!-- Dropdown - Shopping Cart  -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    SHELTER SHOP
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <!-- <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div> -->
                                    </div>
                                    <div>
                                        <!-- <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span> -->
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Shop Notifications</a>
                            </div>
                        </li>


                        

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $firstName . ' ' . $lastName; ?></span>
                                <img class="img-profile rounded-circle"
                                    src="user.png">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="userProfileV2.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <!-- <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a> -->
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->
                <!-- <table class="table table-bordered" style="margin: 10px;">
                    <thread>
                        <tr>
                            <th> Animal Name </th>
                            <th> Adoption Date </th>
                            <th> Status </th>
                </table> -->
                <div class="container">
                <div class="card1" id="animalCard">
                    <img id="animalImage" src="" alt="Animal Image" class="card-img">
                    <div class="card-body">
                        <h3 id="animalName"></h3>
                        <p id="gender"></p>
                        <p id="status"></p>
                        <p id="age"></p>
                        <!-- <button class="btn btn-primary" onclick="showAnimalDetails(<?php echo $animalId; ?>)">View Details</button> -->
                    </div>
                </div>

                <!-- MultiStep Form -->

                <?php 
                require 'connection.php';

                if (isset($_POST["submitAdoption"])) {
                    $icon = 'info'; // Example value
                    $title = 'Confirmation'; // Example value
                    $text = 'Are you sure about you adopted?'; // Example value
                
                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            document.getElementById('msform').addEventListener('submit', function(event) {
                                event.preventDefault(); // Prevent form submission
                                
                                Swal.fire({
                                    icon: '{$icon}',
                                    title: '{$title}',
                                    text: '{$text}',
                                    showCancelButton: true,
                                    confirmButtonText: 'Yes, I am sure',
                                    cancelButtonText: 'No, cancel',
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        // Proceed with form submission
                                        this.submit();
                                    } else {
                                        // User cancelled the submission
                                        Swal.fire('Cancelled', 'Your adoption process has been cancelled.', 'error');
                                    }
                                });
                            });
                        });
                    </script>";

                // if (isset($_POST["submitAdoption"])) {
                    // Validate and sanitize form inputs
                    $animalName = $_POST["animalName"] ?? '';
                    $applicationDate = $_POST["applicationDate"] ?? '';
                    $name = $_POST["name"] ?? '';
                    $age = $_POST["age"] ?? '';
                    $emailAddress = $_POST["emailAddress"] ?? '';
                    $location = $_POST["location"] ?? '';
                    $contactNo = $_POST["contactNo"] ?? '';
                    $profession = $_POST["profession"] ?? '';
                    $fbName = $_POST["fbName"] ?? '';
                    $fbLink = $_POST["fbLink"] ?? '';
                    $data1 = $_POST["data1"] ?? '';
                    $data2 = $_POST["data2"] ?? '';
                    $data3 = $_POST["data3"] ?? '';
                    $data4 = $_POST["data4"] ?? '';
                    $data5 = $_POST["data5"] ?? '';
                    $data6 = $_POST["data6"] ?? '';
                    $data7 = $_POST["data7"] ?? '';
                    $data8 = $_POST["data8"] ?? '';
                    $data9 = $_POST["data9"] ?? '';
                    $data10 = $_POST["data10"] ?? '';
                    $data11 = $_POST["data11"] ?? '';
                    $data12 = $_POST["data12"] ?? '';
                    $data13 = $_POST["data13"] ?? '';
                    $data14 = $_POST["data14"] ?? '';
                    $data15 = $_POST["data15"] ?? '';
                    $data16 = $_POST["data16"] ?? '';
                    $data17 = $_POST["data17"] ?? '';
                    $data18 = $_POST["data18"] ?? '';
                    $data19 = $_POST["data19"] ?? '';
                    $data20 = $_POST["data20"] ?? '';
                    $data21 = $_POST["data21"] ?? '';
                    $data22 = $_POST["data22"] ?? '';
                    $data23 = $_POST["data23"] ?? '';
                    $data24 = $_POST["data24"] ?? '';
                    $data25 = $_POST["data25"] ?? '';
                    $data26 = $_POST["data26"] ?? '';
                    $data27 = $_POST["data27"] ?? '';
                    $data28 = $_POST["data28"] ?? '';
                    $data29 = $_POST["data29"] ?? '';
                    $data30 = $_POST["data30"] ?? '';
                    $data31 = $_POST["data31"] ?? '';
                    $checkbox = $_POST["checkbox"] ?? '';

                    // Prepare and bind
                    if ($stmt = $conn->prepare("INSERT INTO adoption (animalName, applicationDate, name, age, emailAddress, location, contactNo, profession, fbName, fbLink, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11, data12, data13, data14, data15, data16, data17, data18, data19, data20, data21, data22, data23, data24, data25, data26, data27, data28, data29, data30, data31, checkbox) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                        $stmt->bind_param("ssssssssssssssssssssssssssssssssssssssssss", 
                            $animalName, $applicationDate, $name, $age, $emailAddress, $location, 
                            $contactNo, $profession, $fbName, $fbLink, $data1, $data2, $data3, 
                            $data4, $data5, $data6, $data7, $data8, $data9, $data10, $data11, 
                            $data12, $data13, $data14, $data15, $data16, $data17, $data18, 
                            $data19, $data20, $data21, $data22, $data23, $data24, $data25, 
                            $data26, $data27, $data28, $data29, $data30, $data31, $checkbox
                        );

                       // Execute the prepared statement
                        if ($stmt->execute()) {
                            // Insertion successful
                            echo "<script>
                                Swal.fire('Success!', 'Animal adoption details saved successfully.', 'success').then(() => {
                                    window.location.href = 'adoptionHistory.php'; // Redirect to another page after success
                                });
                            </script>";
                        } else {
                            // Insertion failed
                            echo "<script>Swal.fire('Error', 'Failed to save adoption details. Error: " . $stmt->error . "', 'error');</script>";
                        }

                        // Close the prepared statement
                        $stmt->close();
                    } else {
                        // Error preparing SQL statement
                        echo "<script>alert('Error', 'Failed to prepare the SQL statement. Error: " . $conn->error . "', 'error');</script>";
                    }

                    // Close the database connection
                    $conn->close();
                }
                ?>

                <div class="container-fluid" id="grad1">
                    <div class="justify-content-center mt-0">
                        <div class="col-11 col-sm-9 col-md-7 col-lg-6 text-center p-0 mt-3 mb-2">
                            <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                                <h2 style="font-size: 22px; text-transform: uppercase;"><strong>Adoption Application</strong></h2>
                                <h2 style="font-size: 20px;"><strong>Second Chance Aspin Shelter Philippines, Inc.</strong></h2>
                                <p style="justify-content: justify;">
                                    Please fill in with correct information. Make sure that you will enter your active e-mail and mobile numbers. 
                                    Take note that personal information is vital for the process of your adoption.
                                </p>
                                <div class="row">
                                    <div class="col-md-12 mx-0">
                                        <form id="msform" method="POST" action="">
                                            <!-- progressbar -->
                                            <ul id="progressbar">
                                                <li class="active" id="account"><strong>Personal Info</strong></li>
                                                <li id="personal"><strong>Adoption Info</strong></li>
                                                <li id="payment"><strong>Additional Requirements</strong></li>
                                                <li id="confirm"><strong>Finish</strong></li>
                                            </ul>
                                            <!-- fieldsets -->
                                            <fieldset>
                                                <div class="form-card">
                                                    <label for="animalName">Animal Name: <span class="required">*</span></label>
                                                    <input type="text" name="animalName" id="animalNameInput" placeholder="" readonly required>
                                                    
                                                    <label for="applicationDate">Date of Application: <span class="required">*</span></label>
                                                    <input type="date" name="applicationDate" placeholder="Date of Application" required/>

                                                    <label for="name">Name: <span class="required">*</span></label>
                                                    <input type="text" name="name" placeholder="Enter your name" 
                                                        value="<?php echo htmlspecialchars($firstName . ' ' . $lastName); ?>" readonly required/>

                                                    <label for="age">Age: <span class="required">*</span></label>
                                                    <input type="text" name="age" placeholder="" required/>

                                                    <label for="emailAddress">Email Address: <span class="required">*</span></label>
                                                    <input type="email" name="emailAddress" placeholder="" required/>
                                                    
                                                    <label for="location">Address: <span class="required">*</span></label>
                                                    <input type="text" name="location" placeholder="" required/>

                                                    <label for="contactNo">Contact Number/s: <span class="required">*</span></label>
                                                    <input type="tel" name="contactNo" placeholder="" required/>

                                                    <label for="profession">What is your profession? (Please put if you are still a student and what grade level) <span class="required">*</span></label>
                                                    <input type="text" name="profession" placeholder="" required/>

                                                    <label for="fbName">Facebook Profile Name <span class="required">*</span></label>
                                                    <input type="text" name="fbName" placeholder="" required/>

                                                    <label for="fbLink">Facebook Profile Link <span class="required">*</span></label>
                                                    <input type="text" name="fbLink" placeholder="" required/>
                                                </div>
                                                <input type="button" name="next" class="next action-button" value="Next"/>
                                            </fieldset>
                                            <fieldset>
                                                <div class="form-card">
                                                    <label for="data1">Why did you decide to adopt an animal? <span class="required">*</span></label>
                                                    <input type="text" name="data1" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data2">Have you adopted from us before? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data2" name="data2" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data3">If YES, when? (put N/A if otherwise)</label>
                                                    <input type="date" name="data3" placeholder=""/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data4">What type of residence do you live in? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data4" name="data4" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Condominium">Condominium</option>
                                                                <option value="Apartment">Apartment</option>
                                                                <option value="Detached House (with fence/gate)">Detached House (with fence/gate)</option>
                                                                <option value="Detached House (without fence/gate)">Detached House (without fence/gate)</option>
                                                                <option value="Townhouse (with fence/gate)">Townhouse (with fence/gate)</option>
                                                                <option value="Townhouse (without fence/gate)">Townhouse (without fence/gate)</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data5">Is the residence for RENT? If YES, please secure a written letter from your landlord that pets are allowed. (put N/A if otherwise)</label>
                                                    <input type="file" name="data5" placeholder=""/>

                                                    <label for="data6">Who do you live with? Please be specific. <span class="required">*</span></label>
                                                    <input type="text" name="data6" placeholder="" required/>

                                                    <label for="data7">How long have you lived in the address registered here? <span class="required">*</span></label>
                                                    <input type="text" name="data7" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data8">Are you planning to move in the next six (6) months? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data8" name="data8" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data9">If YES, where? Please leave a specific address. (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data9" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data10">Will the whole family be involved in the care of the animal? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data10" name="data10" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data11">If NO, please explain. (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data11" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data12">Is there anyone in your household who has objection(s) to the arrangement? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data12" name="data12" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data13">If YES, please explain. (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data13" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data14">Are there any children who visit your home frequently? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data14" name="data14" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data15">Are there any other regular visitors on your home which your new companion (dog) must get along? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data15" name="data15" required>
                                                                <option  value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data16">Are there any member of your household who has an allergy to cats and dogs? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data16" name="data16" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data17">If YES, who? (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data17" placeholder="" required/>

                                                    <label for="data18">What will happen to this animal if you have to move unexpectedly? <span class="required">*</span></label>
                                                    <input type="text" name="data18" placeholder="" required/>

                                                    <label for="data19">What kind of behavior(s) of the dog do you feel you will be unable to accept? <span class="required">*</span></label>
                                                    <input type="text" name="data19" placeholder="" required/>

                                                    <label for="data20">How many hours in an average work day will your companion animal spend without a human? <span class="required">*</span></label>
                                                    <input type="text" name="data20" placeholder="" required/>

                                                    <label for="data21">What will happen to your companion animal when you go on vacation or in case of emergency? <span class="required">*</span></label>
                                                    <input type="text" name="data21" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data22">Do you have a regular veterinarian? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data22" name="data22" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data23">If YES, please provide these information: Name, Address and Contact Number (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data23" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data24">Do you have other companion animals? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data24" name="data24" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data25">If YES, please specify what type and the total number. (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data25" placeholder="" required/>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="pay" for="data26">In which part of the house will the animal stay? <span class="required">*</span></label>
                                                            <select class="list-dt" id="data26" name="data26" required>
                                                                <option value="" disabled selected></option>
                                                                <option value="Inside the house ONLY">Inside the house ONLY</option>
                                                                <option value="Inside/Outside the house">Inside/Outside the house</option>
                                                                <option value="Outside the house ONLY">Outside the house ONLY</option>
                                                            </select>
                                                        </div>
                                                    </div><br>

                                                    <label for="data27">Where will this animal be kept during the day and during night? Please specify. <span class="required">*</span></label>
                                                    <input type="text" name="data27" placeholder="" required/>

                                                    <label for="data28">Do you have a fenced yard? If YES, please specify the height and type. (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data28" placeholder="" required/>

                                                    <label for="data29">If NO fence, how will you handle the dog's exercise and toilet duties? (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data29" placeholder="" required/>

                                                    <label for="data30">If adopting a cat, where will be the litter box be kept? (put N/A if otherwise)<span class="required">*</span></label>
                                                    <input type="text" name="data30" placeholder="" required/>
                                               </div>
                                                <input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                                                <input type="button" name="next" class="next action-button" value="Next"/>
                                            </fieldset>
                                            <fieldset>
                                                <div class="form-card">
                                                    
                                                    <h2 style="font-size: 16px; text-align: center; font-weight: bold;">Second Chance Aspin Shelter Philippines, Inc. reserves the right to refuse an adoption.</h2>
                                                    <!-- <h2 class="fs-title">Valid ID</h2> --><br><br>

                                                    <label for="data31">Upload a Valid ID <span class="required">*</span></label>
                                                    <input type="text" name="data31" placeholder="" required/>

                                                    <h2 style="font-size: 14px;">
                                                        Please secure the following requirements:<br>
                                                            1. Government Issued and company ID<br>
                                                            2. A copy of the signature above the printed name on a sheet of paper (scanned/photo)<br><br>

                                                            FOR APPLICANTS BELOW 18  YEARS OLD:<br>
                                                            1. School ID<br>
                                                            2. Birth <br>
                                                            3. Parent's/Guardian's government-issued ID<br>
                                                            4. A copy of the signature above the printed name of the parent/guardian on a sheet of paper (scanned/photo)<br></h2>
                                                </div>
                                                <input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                                                <input type="button" name="next" class="next action-button" value="Next"/>
                                            </fieldset>
                                            <fieldset>
                                                <div class="form-card">
                                                    <label for="checkbox">I certify that the above information is true and understand that false information may result in automatic nullification of my proposed adoption. <span class="required">*</span></label>
                                                    <input type="checkbox" name="checkbox" required/>
                                                </div>
                                                <input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                                                <input type="submit" name="submitAdoption" class="next action-button" value="Submit"/>
                                            </fieldset>                           
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Include SweetAlert2 JavaScript -->
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

                <div class="loading-wrapper">
                    <div class="loading-paw"></div>
                </div>


               

    <!-- <table class="table table-bordered">
			<thread>
				<tr>
					<th> FirstName </th>
                    <th> LastName </th>
                    <th> Adoption Date </th>
					
				</tr>
			</thread>
			<tbody>
				<?php
				// 	$link = mysqli_connect("localhost", "root", "arktechdb", "ojtDatabase");

				// 	if ($link === false) 
				// 	{
				// 		die("ERROR: Could not connect. "
				// 		.mysqli_connect_error());
				// 	}
					
				// 	// Check if the refresh button is clicked
				// 	if (isset($_POST['refresh'])) {
				// 		// Redirect to the same page to clear the filter
				// 		header("Location: ".$_SERVER['PHP_SELF']);
				// 		exit();
				// 	}
					
				// 	$sql = "SELECT tbl_Employee.id, tbl_Employee.firstName, tbl_Employee.lastName, tbl_Employee.Gender, tbl_Employee.Address, tbl_Employee.Birthday, hr_department.departmentName 
				// 	FROM tbl_Employee 
				// 	INNER JOIN hr_department ON tbl_Employee.departmentId = hr_department.departmentId WHERE 1=1";

				// 	//filter condition
				// 	if (!empty($_POST['firstName'])) {
				// 		$firstName = mysqli_real_escape_string($link, $_POST['firstName']);
				// 		$sql .= " AND firstName LIKE '%$firstName%'";
				// 	}

				// 	if (!empty($_POST['lastName'])) {
				// 		$lastName = mysqli_real_escape_string($link, $_POST['lastName']);
				// 		$sql .= " AND lastName LIKE '%$lastName%'";
				// 	}

				// 	$gender = $_POST['gender'];
				// 	if ($gender != ''){
				// 		$gender = mysqli_real_escape_string($link, $_POST['gender']);
				// 		$sql .= " AND Gender = '$gender'";
				// 	}

				// 	if (!empty($_POST['Address'])) {
				// 		$Address = mysqli_real_escape_string($link, $_POST['Address']);
				// 		$sql .= " AND Address LIKE '%$Address%'";
				// 	}

				// 	if (!empty($_POST['Birthday'])) {
				// 		$Birthday = mysqli_real_escape_string($link, $_POST['Birthday']);
				// 		$sql .= " AND Birthday LIKE '%$Birthday%'";
				// 	}

				// 	if (!empty($_POST['departmentId'])) 
				// 	{
				// 		$departmentId = mysqli_real_escape_string($conn, $_POST['departmentId']);
				// 		$sql .= " AND tbl_Employee.departmentId = '$departmentId'";
				// 	}

				// 	//


				// 	if ($res = mysqli_query($link, $sql)) 
				// 	{
				// 		if (mysqli_num_rows($res) > 0) 
				// 		{
                //             $counter = 1;

				// 			while ($row = mysqli_fetch_array($res)) 
				// 			{
				// 				$Birthday = date('F j, Y', strtotime($row["Birthday"]));
                //                 $birthDate = new DateTime($row["Birthday"]);
                //                 $today = new DateTime();
                //                 $age = $today->diff($birthDate)->y;

				// 				echo "<tr>";
                //                 echo "<td>" . $counter . "</td>";
				// 				echo "<td>".$row['firstName']."</td>";
				// 				echo "<td>".$row['lastName']."</td>";
				// 				echo "<td>". ($row['Gender'] == 0 ?'Male' : 'Female') ."</td>";
				// 				echo "<td>".$row['Address']."</td>";
				// 				echo "<td>".$Birthday ."</td>";
                //                 echo "<td>".$age."</td>";
				// 				echo "<td>" . $row['departmentName'] . "</td>"; 
                //                 echo '<td><a class="update remove" href="abi_update.php?id='.$row['id'].'">
                //                       <i class="glyphicon glyphicon-pencil"></i></a>
				// 		                  <a class="delete remove" href="abi_delete.php?id='.$row['id'].'">
                //                           <i class="glyphicon glyphicon-trash"></i></a></td></tr>';
                                
                //                 $counter++;
                //                 }
                    
				// 				echo "</table>";
				// 				mysqli_free_result($res);
				// 		}
				// 		else 
				// 		{
				// 			echo "No matching records are found.";
				// 		}
				// 	}
				// 	else 
				// 	{
				// 		echo "ERROR: Could not able to execute $sql. "
				// 		.mysqli_error($link);
				// 	}
				// 	mysqli_close($link);
				// ?>
			</tbody>
    	</table>
     -->

     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

        <?php
        // Display success message if set in session
        if (isset($_SESSION['success_message'])) {
            alert('Success', $_SESSION['success_message'], 'success');
            unset($_SESSION['success_message']); // Clear the success message after displaying
        }
        ?>


     <div class="modal fade" id="animalModal" tabindex="-1" role="dialog" aria-labelledby="animalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="animalModalLabel"><strong>Help them find a new home!</strong></h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid" id="modalContent">
                    <div class="row">
                        <!-- Image Section -->
                        <div class="col-md-4">
                            <img src="" id="animalImage" class="img-fluid rounded" alt="Animal Image">
                            
                        </div>
                        <!-- Animal Details Section -->
                        <div class="col-md-4">
                            <h5 class="modal-section-title">Animal Details</h5>
                            <p><strong>Name:</strong> <span id="animalName"></span></p>
                            <p><strong>Species:</strong> <span id="animalSpecies"></span></p>
                            <p><strong>Gender:</strong> <span id="animalGender"></span></p>
                            <p><strong>Status:</strong> <span id="animalStatus"></span></p>
                            <p><strong>Age:</strong> <span id="animalAge"></span></p>
                            <p><strong>Birthday:</strong> <span id="animalBirthday"></span></p>
                            <p><strong>Intake Type:</strong> <span id="animalIntakeType"></span></p>
                            <p><strong>Intake Date:</strong> <span id="animalIntakeDate"></span></p>
                            <p><strong>Description:</strong> <span id="animalDescription"></span></p>
                        </div>
                        <!-- Medical Info Section -->
                        <div class="col-md-4">
                            <h5 class="modal-section-title">Others</h5>
                            <p><strong>Condition:</strong> <span id="animalCondition"></span></p>
                            <p><strong>Anti Rabies:</strong> <span id="animalAntiRabies"></span></p>
                            <p><strong>5-in-1 Vaccine:</strong> <span id="animalVaccine"></span></p>
                            <p><strong>Neutered:</strong> <span id="animalNeutered"></span></p> 
                            <p><strong>Deticked:</strong> <span id="animalDeticked"></span></p>
                            <p><strong>Dewormed:</strong> <span id="animalDewormed"></span></p>
                            <!-- Add more medical info as needed -->
                        </div>
                    </div><br>
                    <div class="modal-footer">
                        <!-- <a href="adopt.php" type="submit" name="submitAnimal" class="btn btn-secondary">Adopt Now</a> -->
                  
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>



         <!-- Bootstrap core JavaScript-->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="js/sb-admin-2.min.js"></script>

        <!-- Page level plugins -->
        <script src="vendor/chart.js/Chart.min.js"></script>

        <!-- Page level custom scripts -->
        <script src="js/demo/chart-area-demo.js"></script>
        <script src="js/demo/chart-pie-demo.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const queryParams = new URLSearchParams(window.location.search);
            const animalId = queryParams.get('animalId');

            if (animalId) {
                fetch(`getAnimalDetails2.php?animalId=${animalId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            alert(data.error);
                        } else {
                            document.getElementById('animalImage').src = data.image;
                            document.getElementById('animalName').textContent = data.animalName;
                            document.getElementById('gender').textContent = `Gender: ${data.gender}`;
                            document.getElementById('status').textContent = `Status: ${data.status}`;
                            document.getElementById('age').textContent = `Age: ${data.age}`;

                            const animalNameInput = document.getElementById('animalNameInput');
                            animalNameInput.value = data.animalName;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Failed to fetch animal details.');
                    });
            } else {
                alert('Invalid animalId.');
            }
        });

        function showAnimalDetails(animalId) {
        // AJAX request to fetch animal details
            $.ajax({
                url: 'getAnimalDetails2.php',
                type: 'GET',
                data: { animalId: animalId },
                dataType: 'json', // Expect JSON response
                success: function(response) {
                    // Populate modal with fetched data
                    $('#animalImage').attr('src', response.image);
                    $('#animalName').text(response.animalName);
                    $('#animalSpecies').text(response.species);
                    $('#animalGender').text(response.gender);
                    $('#animalStatus').text(response.status);
                    $('#animalAge').text(response.age);
                    $('#animalBirthday').text(response.birthday);
                    $('#animalIntakeType').text(response.intakeType);
                    $('#animalIntakeDate').text(response.intakeDate);
                    $('#animalDescription').text(response.description);
                    $('#animalCondition').text(response.conditions);
                    $('#animalAntiRabies').text(response.antiRabies);
                    $('#animalVaccine').text(response.vaccine);
                    $('#animalNeutered').text(response.neutered);
                    $('#animalDeticked').text(response.deticked);
                    $('#animalDewormed').text(response.dewormed);


                    $('#animalModal').modal('show'); // Show the modal
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching animal details:', error);
                    alert('Error fetching animal details.');
                }
            });
        }


        $(document).ready(function(){
    
        var current_fs, next_fs, previous_fs; //fieldsets
        var opacity;
        
        $(".next").click(function(){
            
            current_fs = $(this).parent();
            next_fs = $(this).parent().next();
            
            //Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
            
            //show the next fieldset
            next_fs.show(); 
            //hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;
        
                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({'opacity': opacity});
                }, 
                duration: 600
            });
        });
        
        $(".previous").click(function(){
            
            current_fs = $(this).parent();
            previous_fs = $(this).parent().prev();
            
            //Remove class active
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
            
            //show the previous fieldset
            previous_fs.show();
        
            //hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;
        
                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    previous_fs.css({'opacity': opacity});
                }, 
                duration: 600
            });
        });
        
        $('.radio-group .radio').click(function(){
            $(this).parent().find('.radio').removeClass('selected');
            $(this).addClass('selected');
        });
        
        $(".submit").click(function(){
            return false;
        })
            
        });


        // Function to show loading wheel
        function showLoading() {
        document.querySelector('.loading-wrapper').style.display = 'block';
        }

        // Function to hide loading wheel
        function hideLoading() {
        document.querySelector('.loading-wrapper').style.display = 'none';
        }

        // Function to handle homepage link click event
        function handleHomepageLinkClick(event) {
        // Prevent the default action (i.e., following the link immediately)
        event.preventDefault();

        // Show loading wheel
        showLoading();

        // Redirect to the homepage after a delay (simulated redirect)
        setTimeout(function() {
            // Hide loading wheel
            hideLoading();

            // Get the href attribute of the clicked link and navigate to that URL
            window.location.href = event.target.href;
        }, 2000); // Change 2000 to the desired delay in milliseconds
        }

        // Attach click event listener to the homepage link
        document.getElementById('homepageLink').addEventListener('click', handleHomepageLinkClick);


        
    </script>



</body>
</html>